One of Steve's laptop's got hit with some ransomware and he really needs this document recovered. Can you figure out how to decrypt ransomware_doc.txt?
